<?php if (isset($component)) { $__componentOriginal9d41032d5dde91ab243771384dacb5df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d41032d5dde91ab243771384dacb5df = $attributes; } ?>
<?php $component = App\View\Components\FrontLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <!-- Header Start -->
     <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">Rentals</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="/">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Rent</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->

        <!-- Team Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="section-title bg-white text-center text-primary px-3">Rent One of Our Rooms</h6>
                    <h1 class="mb-5">Rent a Room</h1>
                </div>
                <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card shadow mb-4 wow fadeInUp" data-wow-delay="0.3s"> 
                    <div class="card-body">
                      <div class="row">
                          <div class="col-md-6">
                              <div id="myCarousel<?php echo e($rent->id); ?>" class="carousel slide" data-bs-ride="carousel">
                                  <div class="carousel-inner">
                                    <?php $__currentLoopData = $rent->rentalimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                                      <img src="<?php echo e(asset('asset/image/'. $img->image)); ?>"  width="100%" height="100%" alt="">
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                  <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel<?php echo e($rent->id); ?>" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                  </button>
                                  <button class="carousel-control-next" type="button" data-bs-target="#myCarousel<?php echo e($rent->id); ?>" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                  </button>
                                </div>
                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="card mb-4 rounded-3 shadow-sm mt-5">
                                  <div class="card-header py-3">
                                    <h4 class="my-0 fw-normal"><?php echo e($rent->title); ?></h4>
                                  </div>
                                  <div class="card-body">
                                    <h1 class="card-title pricing-card-title">£<?php echo e(number_format($rent->price)); ?><small class="text-muted fw-light">/day</small></h1>
                                    <h6>Room Features</h6>
                                    <ul class="list-unstyled mt-3 mb-4">
                                      <?php if($rent->features): ?>
                                        <?php $__currentLoopData = explode(',', $rent->features); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($feature); ?> </li>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php endif; ?>
                                    </ul>
                                    <a href="/pay/<?php echo e($rent->id); ?>" class="w-100 btn btn-lg btn-primary">Book Room</a>
                                  </div>
                                </div>
                          </div>
                      </div>
                  </div>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div>
              <?php echo e($rents->links()); ?>

            </div>
        </div>
        <!-- Team End -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $attributes = $__attributesOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__attributesOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $component = $__componentOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__componentOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/hacaWeb/resources/views/front/rent.blade.php ENDPATH**/ ?>